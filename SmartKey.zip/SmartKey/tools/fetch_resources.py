#!/usr/bin/env python3
"""Downloads open-source resources into app/src/main/assets (run on your PC or in GitHub Actions).
Sources & licenses:
  - hermitdave/FrequencyWords (CC-BY-SA 4.0)      -> dict_ar.txt / dict_en.txt
  - Tatoeba sentences (CC-BY 2.0 FR)              -> bigram_ar.txt / bigram_en.txt
  - Unicode emoji-test.txt (Unicode License)       -> emoji.txt
  - Google Fonts (SIL OFL 1.1): Tajawal, Amiri, Cairo, Noto Sans Arabic, Noto Color Emoji
Optional: drop OpenMoji.ttf / Twemoji.ttf (COLR or CBDT/glyf color fonts) into assets/fonts to enable them in settings.
"""
import bz2, collections, io, os, re, sys, urllib.request, urllib.parse

ASSETS = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets")
os.makedirs(os.path.join(ASSETS, "fonts"), exist_ok=True)

def get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "SmartKey-build"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def attempt(label, fn):
    try:
        fn(); print("OK  ", label)
    except Exception as e:
        print("SKIP", label, "->", e)

STRIP = re.compile("[\u064B-\u065F\u0670\u0640]")
AR_RE = re.compile(r"^[\u0621-\u064A]{1,25}$")
EN_RE = re.compile(r"^[a-z']{1,25}$")

def build_dict(lang, urls, rx, cap):
    data = None
    for u in urls:
        try: data = get(u).decode("utf-8", "ignore"); break
        except Exception as e: print("   fail", u, e)
    if data is None: raise RuntimeError("no frequency list")
    words = {}
    for line in data.splitlines():
        p = line.split()
        if len(p) != 2 or not p[1].isdigit(): continue
        w = STRIP.sub("", p[0]) if lang == "ar" else p[0].lower()
        if rx.match(w): words[w] = words.get(w, 0) + int(p[1])
    top = sorted(words.items(), key=lambda kv: -kv[1])[:cap]
    with open(os.path.join(ASSETS, f"dict_{lang}.txt"), "w", encoding="utf-8") as f:
        for w, c in top: f.write(f"{w}\t{c}\n")
    print("   words:", len(top)); return {w for w, _ in top}

def build_bigrams(lang, tatoeba_code, vocab, tok):
    raw = bz2.decompress(get(f"https://downloads.tatoeba.org/exports/per_language/{tatoeba_code}/{tatoeba_code}_sentences.tsv.bz2", 600)).decode("utf-8", "ignore")
    cnt = collections.Counter()
    for line in raw.splitlines():
        parts = line.split("\t")
        if len(parts) < 3: continue
        ws = [STRIP.sub("", w) if lang == "ar" else w.lower() for w in tok.findall(parts[2])]
        for a, b in zip(ws, ws[1:]):
            if a in vocab and b in vocab: cnt[(a, b)] += 1
    per = collections.defaultdict(list)
    for (a, b), c in cnt.most_common():
        if c >= 2 and len(per[a]) < 6: per[a].append((b, c))
    with open(os.path.join(ASSETS, f"bigram_{lang}.txt"), "w", encoding="utf-8") as f:
        for a, lst in per.items():
            for b, c in lst: f.write(f"{a} {b}\t{c}\n")
    print("   bigram heads:", len(per))

def emoji():
    txt = get("https://unicode.org/Public/emoji/latest/emoji-test.txt").decode("utf-8")
    group = None; out = collections.OrderedDict()
    for line in txt.splitlines():
        if line.startswith("# group:"): group = line.split(":", 1)[1].strip(); out.setdefault(group, []); continue
        if not line or line.startswith("#") or group in (None, "Component"): continue
        m = re.match(r"^([0-9A-F ]+)\s*;\s*fully-qualified\s*#\s*(\S+)\s+E[\d.]+\s+(.*)$", line)
        if not m: continue
        if re.search(r"1F3F[B-F]", m.group(1)): continue   # skip skin-tone variants
        out[group].append((m.group(2), m.group(3)))
    with open(os.path.join(ASSETS, "emoji.txt"), "w", encoding="utf-8") as f:
        for g, items in out.items():
            f.write(f"##{g}\n")
            for e, n in items: f.write(f"{e}\t{n}\n")
    print("   emoji:", sum(len(v) for v in out.values()))

FU = "https://github.com/google/fonts/raw/main/ofl/"
FONTS = {
    "Tajawal-Medium.ttf": FU + "tajawal/Tajawal-Medium.ttf",
    "Tajawal-Bold.ttf": FU + "tajawal/Tajawal-Bold.ttf",
    "Amiri-Regular.ttf": FU + "amiri/Amiri-Regular.ttf",
    "Cairo.ttf": FU + "cairo/Cairo%5Bslnt%2Cwght%5D.ttf",
    "NotoSansArabic.ttf": FU + "notosansarabic/NotoSansArabic%5Bwdth%2Cwght%5D.ttf",
    "NotoColorEmoji.ttf": FU + "notocoloremoji/NotoColorEmoji-Regular.ttf",
}

if __name__ == "__main__":
    FW = "https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/"
    vocab = {}
    def d_ar(): vocab["ar"] = build_dict("ar", [FW + "ar/ar_full.txt", FW + "ar/ar_50k.txt"], AR_RE, 150000)
    def d_en(): vocab["en"] = build_dict("en", [FW + "en/en_full.txt", FW + "en/en_50k.txt"], EN_RE, 150000)
    attempt("Arabic dictionary", d_ar); attempt("English dictionary", d_en)
    if "ar" in vocab: attempt("Arabic bigrams", lambda: build_bigrams("ar", "ara", vocab["ar"], re.compile(r"[\u0621-\u064A\u064B-\u065F]+")))
    if "en" in vocab: attempt("English bigrams", lambda: build_bigrams("en", "eng", vocab["en"], re.compile(r"[A-Za-z']+")))
    attempt("Emoji list", emoji)
    for name, url in FONTS.items():
        attempt("font " + name, lambda n=name, u=url: open(os.path.join(ASSETS, "fonts", n), "wb").write(get(u, 300)))
