package app.smartkey

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import app.smartkey.data.ClipboardDb
import app.smartkey.engine.UserDb

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "SmartKey"
        val d = dp(1f).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(Button(this).apply { text = "1) تفعيل الكيبورد"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
        root.addView(Button(this).apply { text = "2) اختيار الكيبورد"; setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
        root.addView(EditText(this).apply { hint = "جرّب الكتابة هنا…"; setPadding(16 * d, 12 * d, 16 * d, 12 * d) })
        val container = FrameLayout(this).apply { id = View.generateViewId() }
        root.addView(container, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        supportFragmentManager.beginTransaction().replace(container.id, Prefs()).commit()
    }

    class Prefs : PreferenceFragmentCompat() {
        override fun onCreatePreferences(s: Bundle?, key: String?) {
            setPreferencesFromResource(R.xml.prefs, key)
            findPreference<Preference>("clear_learning")?.setOnPreferenceClickListener {
                UserDb(requireContext()).clear(); Toast.makeText(context, "تم المسح", Toast.LENGTH_SHORT).show(); true
            }
            findPreference<Preference>("clear_clip")?.setOnPreferenceClickListener {
                ClipboardDb(requireContext()).clearUnpinned(); Toast.makeText(context, "تم المسح", Toast.LENGTH_SHORT).show(); true
            }
        }
    }
}
