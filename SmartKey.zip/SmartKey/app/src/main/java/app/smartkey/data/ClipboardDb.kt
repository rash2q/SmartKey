package app.smartkey.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ClipItem(val id: Long, val content: String, val type: String, val pinned: Boolean, val createdAt: Long)

/** Samsung-style clipboard history: text / link / image(URI), pin, delete, auto-purge. */
class ClipboardDb(ctx: Context) : SQLiteOpenHelper(ctx, "clipboard.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clipboard_items(id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL, type TEXT NOT NULL, is_pinned INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized fun add(content: String, type: String) {
        if (content.isBlank()) return
        val db = writableDatabase
        val pinned = db.rawQuery("SELECT is_pinned FROM clipboard_items WHERE content=?", arrayOf(content)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        db.delete("clipboard_items", "content=?", arrayOf(content))
        db.insert("clipboard_items", null, ContentValues().apply {
            put("content", content); put("type", type); put("is_pinned", pinned); put("created_at", System.currentTimeMillis())
        })
        db.execSQL("DELETE FROM clipboard_items WHERE is_pinned=0 AND id NOT IN (SELECT id FROM clipboard_items WHERE is_pinned=0 ORDER BY created_at DESC LIMIT 100)")
    }

    @Synchronized fun list(pinned: Boolean): List<ClipItem> {
        val out = ArrayList<ClipItem>()
        readableDatabase.rawQuery("SELECT id,content,type,is_pinned,created_at FROM clipboard_items WHERE is_pinned=? ORDER BY created_at DESC", arrayOf(if (pinned) "1" else "0")).use {
            while (it.moveToNext()) out.add(ClipItem(it.getLong(0), it.getString(1), it.getString(2), it.getInt(3) == 1, it.getLong(4)))
        }
        return out
    }

    @Synchronized fun togglePin(id: Long) { writableDatabase.execSQL("UPDATE clipboard_items SET is_pinned = 1 - is_pinned WHERE id=?", arrayOf(id)) }
    @Synchronized fun delete(id: Long) { writableDatabase.delete("clipboard_items", "id=?", arrayOf(id.toString())) }
    @Synchronized fun clearUnpinned() { writableDatabase.delete("clipboard_items", "is_pinned=0", null) }
    @Synchronized fun purge(days: Int) {
        if (days <= 0) return
        writableDatabase.delete("clipboard_items", "is_pinned=0 AND created_at < ?", arrayOf((System.currentTimeMillis() - days * 86_400_000L).toString()))
    }
}
