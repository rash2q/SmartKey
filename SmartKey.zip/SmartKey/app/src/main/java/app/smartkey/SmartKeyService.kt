package app.smartkey

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PointF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import app.smartkey.data.ClipboardDb
import app.smartkey.engine.Engine
import app.smartkey.engine.Norm
import app.smartkey.ui.*
import java.util.concurrent.Executors

class SmartKeyService : InputMethodService(), KeyboardView.Listener {
    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var engine: Engine
    private lateinit var clipDb: ClipboardDb
    private lateinit var root: LinearLayout
    private lateinit var bar: SuggestionBar
    private lateinit var kv: KeyboardView
    private lateinit var frame: FrameLayout
    private var clipPanel: ClipboardPanel? = null
    private var emojiPanel: EmojiPanel? = null
    private var decorPanel: DecorPanel? = null

    private var lang = "ar"
    private var shift = 0
    private var page = -1                  // -1 letters, 0 symbols, 1 more symbols
    private var plain = false              // password / email / url fields: no composing, no suggestions
    private val composing = StringBuilder()
    private var seq = 0
    private var lastShiftTap = 0L
    private var lastSpace = 0L
    private var swipeLast: String? = null
    private var decorLen = 0

    private val prefs get() = prefsOf(this)
    private fun on(k: String, def: Boolean = true) = prefs.getBoolean(k, def)

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    override fun onCreate() {
        super.onCreate()
        engine = Engine(this); clipDb = ClipboardDb(this)
        lang = prefs.getString("lang", "ar") ?: "ar"
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        exec.shutdown(); super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        kv = KeyboardView(this); kv.listener = this
        bar = SuggestionBar(this, { t, lit -> pick(t, lit) }, { tool(it) })
        frame = FrameLayout(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (46 * dp(1f)).toInt()))
        root.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        applyAll(); showKeyboard()
        return root
    }

    private fun applyAll() {
        kv.applyPrefs(); val t = Themes.get(this)
        root.setBackgroundColor(t.bg); bar.applyTheme(t); buildLayout()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        composing.clear(); swipeLast = null
        val cls = info.inputType and InputType.TYPE_MASK_CLASS; val v = info.inputType and InputType.TYPE_MASK_VARIATION
        plain = cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS || v == InputType.TYPE_TEXT_VARIATION_URI) ||
                (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        page = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 0 else -1
        shift = 0
        applyAll(); showKeyboard(); autoCap(); refreshSuggestions()
        exec.execute { clipDb.purge((prefs.getString("clip_days", "7") ?: "7").toInt()) }
    }

    override fun onFinishInput() { composing.clear(); super.onFinishInput() }

    override fun onUpdateSelection(os: Int, oe: Int, ns: Int, ne: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce)
        if (composing.isNotEmpty() && (cs == -1 || ns != ce || ne != ce)) composing.clear()
        refreshSuggestions()
    }

    // ------------------------------------------------------------------ layout / state
    private fun buildLayout() {
        val numRow = on("number_row", true); val hindi = on("hindi_digits", true)
        kv.setLayout(if (page < 0) Layouts.letters(lang, numRow, hindi) else Layouts.symbols(page, lang, hindi))
        kv.shiftState = shift; kv.spaceLabel = if (lang == "ar") "ع" else "EN"
        val info = currentInputEditorInfo; var label = "↵"; var accent = false
        if (info != null && (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 && (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) == 0) {
            when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
                EditorInfo.IME_ACTION_SEARCH -> { label = "بحث"; accent = true }
                EditorInfo.IME_ACTION_SEND -> { label = "إرسال"; accent = true }
                EditorInfo.IME_ACTION_GO -> { label = "اذهب"; accent = true }
                EditorInfo.IME_ACTION_NEXT -> label = "التالي"
                EditorInfo.IME_ACTION_DONE -> label = "تم"
            }
        }
        kv.enterLabel = label; kv.enterAccent = accent
    }

    private fun showKeyboard() {
        frame.removeAllViews()
        val w = resources.displayMetrics.widthPixels
        val oh = prefs.getString("one_hand", "off")
        val lp = if (oh == "off") FrameLayout.LayoutParams(-1, -2) else FrameLayout.LayoutParams((w * 0.82f).toInt(), -2, if (oh == "left") Gravity.START else Gravity.END)
        frame.addView(kv, lp); bar.setPanelMode(false)
    }

    private fun showPanel(v: View) {
        val h = if (kv.height > 0) kv.height else (260 * dp(1f)).toInt()
        frame.removeAllViews(); frame.addView(v, FrameLayout.LayoutParams(-1, h)); bar.setPanelMode(true)
    }

    private fun autoCap() {
        if (lang != "en" || page >= 0 || !on("auto_caps") || shift == 2) return
        val ic = currentInputConnection ?: return; val info = currentInputEditorInfo ?: return
        shift = if (ic.getCursorCapsMode(info.inputType) != 0) 1 else 0; kv.shiftState = shift
    }
    private fun consumeShift() { if (shift == 1) { shift = 0; kv.shiftState = 0 } }

    // ------------------------------------------------------------------ text helpers
    private fun contextPrev(excludeLen: Int): String? {
        val ic = currentInputConnection ?: return null
        var t = ic.getTextBeforeCursor(80, 0)?.toString() ?: return null
        if (excludeLen > 0 && t.length >= excludeLen) t = t.substring(0, t.length - excludeLen)
        val trimmed = t.trimEnd(' ')
        if (trimmed.isEmpty() || trimmed.last() in ".!?؟،؛:\n") return null
        return Regex("[\\p{L}\\p{M}']+").findAll(trimmed).lastOrNull()?.value
    }

    private fun learn(prev: String?, word: String) {
        if (!on("learn") || plain) return
        val l = lang; val w = Norm.clean(l, word); val p = prev?.let { Norm.clean(l, it) }
        exec.execute { engine.user.learn(l, p, w) }
    }

    private fun finishComposing() {
        if (composing.isEmpty()) return
        val w = composing.toString(); val prev = contextPrev(w.length)
        currentInputConnection?.finishComposingText(); composing.clear(); learn(prev, w)
    }

    private fun refreshSuggestions() {
        if (!::bar.isInitialized) return
        if (!on("suggestions") || plain || page >= 0) { bar.clear(); return }
        val my = ++seq; val typed = composing.toString(); val l = lang
        val prev = contextPrev(typed.length)
        val nextOn = on("nextword")
        exec.execute {
            val list: List<String>; var literal: String? = null
            if (typed.isEmpty()) { list = if (nextOn) engine.nextWords(l, prev) else emptyList() }
            else { val r = engine.suggest(l, prev, typed); list = r.list; if (!r.typedKnown) literal = typed }
            handler.post { if (my == seq) bar.set(list, literal) }
        }
    }

    // ------------------------------------------------------------------ KeyboardView.Listener
    override fun onChar(t: String) {
        val ic = currentInputConnection ?: return
        swipeLast = null
        var text = t
        if (lang == "ar" && on("arabic_punct")) text = when (t) { "," -> "،"; "?" -> "؟"; ";" -> "؛"; else -> t }
        val c = text[0]
        val useComposing = !plain && on("suggestions") && page < 0
        if (useComposing && (c.isLetter() || (c == '\'' && composing.isNotEmpty() && lang == "en"))) {
            composing.append(text); ic.setComposingText(composing, 1); consumeShift(); refreshSuggestions()
        } else if (composing.isNotEmpty() && (Character.getType(c) == Character.NON_SPACING_MARK.toInt() || c == 'ـ')) {
            composing.append(text); ic.setComposingText(composing, 1)
        } else if (c.isLetter() && !useComposing) {
            ic.commitText(text, 1); consumeShift()
        } else separator(text)
    }

    private fun separator(text: String) {
        val ic = currentInputConnection ?: return
        if (composing.isNotEmpty()) {
            val w = composing.toString(); val prev = contextPrev(w.length)
            var out = w
            val sep = !text[0].isDigit()
            if (sep && on("autocorrect") && !plain && text != "'") out = engine.quickCorrect(lang, prev, w)
            ic.commitText(out, 1); composing.clear(); learn(prev, out)
        }
        val now = System.currentTimeMillis()
        if (text == " ") {
            if (lang == "en" && on("double_space") && now - lastSpace < 700) {
                val b = ic.getTextBeforeCursor(2, 0)?.toString()
                if (b != null && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                    ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1); lastSpace = 0; autoCap(); refreshSuggestions(); return
                }
            }
            lastSpace = now
        }
        ic.commitText(text, 1)
        if (page >= 0 && text != " " && text[0] !in "#+=") { /* stay on symbols page like iOS for multi-symbol entry */ }
        consumeShift(); autoCap(); refreshSuggestions()
    }

    override fun onSpecial(k: Kind) {
        val ic = currentInputConnection ?: return
        swipeLast = null
        when (k) {
            Kind.DELETE -> {
                if (composing.isNotEmpty()) {
                    composing.deleteCharAt(composing.length - 1)
                    if (composing.isEmpty()) ic.commitText("", 1) else ic.setComposingText(composing, 1)
                } else if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
                else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                autoCap(); refreshSuggestions()
            }
            Kind.SPACE -> separator(" ")
            Kind.ENTER -> {
                finishComposing()
                val info = currentInputEditorInfo; val a = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noAction = info == null || (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 || (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
                if (!noAction && a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(a)
                else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                autoCap(); refreshSuggestions()
            }
            Kind.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
                lastShiftTap = now; kv.shiftState = shift
            }
            Kind.SYMBOLS -> { finishComposing(); page = 0; buildLayout(); refreshSuggestions() }
            Kind.SYMBOLS2 -> { page = 1; buildLayout() }
            Kind.ABC -> { page = -1; buildLayout(); refreshSuggestions() }
            Kind.LANG -> {
                finishComposing(); lang = if (lang == "ar") "en" else "ar"; prefs.edit().putString("lang", lang).apply()
                page = -1; shift = 0; buildLayout(); autoCap(); refreshSuggestions()
            }
            Kind.EMOJI -> { finishComposing(); showEmoji() }
            else -> {}
        }
    }

    override fun onCursor(steps: Int) {
        finishComposing()
        val code = if (steps > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        repeat(kotlin.math.abs(steps)) { sendDownUpKeyEvents(code) }
    }

    override fun onSwipe(path: List<PointF>) {
        if (page >= 0) return
        val centers = kv.centers(); val kw = kv.keyWidth; val l = lang
        finishComposing()
        exec.execute {
            val res = engine.swipe(l, path, centers, kw)
            handler.post {
                if (res.isEmpty() || l != lang) return@post
                val ic = currentInputConnection ?: return@post
                fun cased(w: String) = if (shift > 0 && l == "en") w.replaceFirstChar { it.uppercase() } else w
                val w = cased(res[0])
                val before = ic.getTextBeforeCursor(1, 0)
                if (!before.isNullOrEmpty() && !before[0].isWhitespace()) ic.commitText(" ", 1)
                val prev = contextPrev(0)
                ic.commitText("$w ", 1); swipeLast = w; learn(prev, w); consumeShift()
                bar.set(res.take(3).map { cased(it) }, null)
            }
        }
    }

    // ------------------------------------------------------------------ suggestions
    private fun pick(text: String, literal: Boolean) {
        val ic = currentInputConnection ?: return
        val sw = swipeLast
        if (sw != null) {
            ic.deleteSurroundingText(sw.length + 1, 0); ic.commitText("$text ", 1); swipeLast = text
            learn(contextPrev(0), text); refreshSuggestions(); return
        }
        if (composing.isNotEmpty()) {
            val prev = contextPrev(composing.length)
            ic.commitText("$text ", 1); composing.clear(); learn(prev, text)
        } else {
            val b = ic.getTextBeforeCursor(1, 0)
            val lead = if (!b.isNullOrEmpty() && !b[0].isWhitespace()) " " else ""
            val prev = contextPrev(0)
            ic.commitText("$lead$text ", 1); learn(prev, text)
        }
        lastSpace = System.currentTimeMillis(); autoCap(); refreshSuggestions()
    }

    // ------------------------------------------------------------------ toolbar & panels
    private fun tool(id: String) {
        val ic = currentInputConnection
        when (id) {
            "close" -> { showKeyboard(); refreshSuggestions() }
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "clipboard" -> showClipboard()
            "emoji" -> { finishComposing(); showEmoji() }
            "decor" -> showDecor()
            "ime" -> (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            "onehand" -> {
                val n = when (prefs.getString("one_hand", "off")) { "off" -> "left"; "left" -> "right"; else -> "off" }
                prefs.edit().putString("one_hand", n).apply(); showKeyboard()
            }
            "theme" -> {
                val order = listOf("auto", "ios_light", "ios_dark", "samsung", "midnight", "rose", "emerald", "amoled")
                val n = order[(order.indexOf(prefs.getString("theme", "auto")) + 1) % order.size]
                prefs.edit().putString("theme", n).apply(); applyAll()
            }
            "selectall" -> ic?.performContextMenuAction(android.R.id.selectAll)
            "copy" -> ic?.performContextMenuAction(android.R.id.copy)
            "cut" -> ic?.performContextMenuAction(android.R.id.cut)
            "paste" -> ic?.performContextMenuAction(android.R.id.paste)
        }
    }

    private fun showClipboard() {
        finishComposing()
        val p = clipPanel ?: ClipboardPanel(this, clipDb) { c, t -> pasteClip(c, t) }.also { clipPanel = it }
        p.show(Themes.get(this)); showPanel(p)
    }

    private fun pasteClip(content: String, type: String) {
        val ic = currentInputConnection ?: return
        if (type == "IMAGE") {
            try {
                val info = InputContentInfoCompat(Uri.parse(content), ClipDescription("image", arrayOf("image/png")), null)
                val flags = if (Build.VERSION.SDK_INT >= 25) InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION else 0
                InputConnectionCompat.commitContent(ic, currentInputEditorInfo, info, flags, null)
            } catch (_: Exception) {}
        } else ic.commitText(content, 1)
        showKeyboard()
    }

    private fun captureClip() {
        if (!on("clipboard")) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return; if (clip.itemCount == 0) return
            if (Build.VERSION.SDK_INT >= 33 && clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val item = clip.getItemAt(0)
            exec.execute {
                if (clip.description.hasMimeType("image/*") && item.uri != null) clipDb.add(item.uri.toString(), "IMAGE")
                else {
                    val t = item.text?.toString()
                    if (!t.isNullOrBlank()) clipDb.add(t, if (t.startsWith("http://") || t.startsWith("https://")) "LINK" else "TEXT")
                }
            }
        } catch (_: Exception) {}
    }

    private fun showEmoji() {
        val p = emojiPanel ?: EmojiPanel(this,
            { e -> currentInputConnection?.commitText(e, 1) },
            { showKeyboard(); refreshSuggestions() },
            { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }).also { emojiPanel = it }
        p.show(Themes.get(this)); showPanel(p)
    }

    private fun showDecor() {
        finishComposing()
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString()
        val src: String; var selected = false
        if (!sel.isNullOrEmpty()) { src = sel; selected = true }
        else src = (ic.getTextBeforeCursor(40, 0)?.toString() ?: "").trimEnd().substringAfterLast(' ').substringAfterLast('\n')
        decorLen = if (selected) 0 else src.length
        val p = decorPanel ?: DecorPanel(this) { out ->
            val c = currentInputConnection
            if (c != null) { if (decorLen > 0) c.deleteSurroundingText(decorLen, 0); c.commitText(out, 1) }
            showKeyboard()
        }.also { decorPanel = it }
        p.show(Themes.get(this), src); showPanel(p)
    }
}
