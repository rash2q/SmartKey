package app.smartkey.engine

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlin.math.ln

/** Learns words and word pairs from the user. All reads come from memory; writes go to SQLite. */
class UserDb(ctx: Context) : SQLiteOpenHelper(ctx, "user_lm.db", null, 1) {
    private val uni = HashMap<String, Int>()                       // "lang|word" -> n
    private val bi = HashMap<String, HashMap<String, Int>>()       // "lang|prev" -> word -> n

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE uni(k TEXT PRIMARY KEY, n INTEGER)")
        db.execSQL("CREATE TABLE bi(k TEXT PRIMARY KEY, prev TEXT, word TEXT, n INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    init {
        try {
            readableDatabase.rawQuery("SELECT k,n FROM uni", null).use { c -> while (c.moveToNext()) uni[c.getString(0)] = c.getInt(1) }
            readableDatabase.rawQuery("SELECT prev,word,n FROM bi", null).use { c ->
                while (c.moveToNext()) bi.getOrPut(c.getString(0)) { HashMap() }[c.getString(1)] = c.getInt(2)
            }
        } catch (_: Exception) {}
    }

    @Synchronized fun learn(lang: String, prev: String?, word: String) {
        if (word.length < 2) return
        val k = "$lang|$word"; val n = (uni[k] ?: 0) + 1; uni[k] = n
        val db = writableDatabase
        db.insertWithOnConflict("uni", null, ContentValues().apply { put("k", k); put("n", n) }, SQLiteDatabase.CONFLICT_REPLACE)
        if (!prev.isNullOrEmpty()) {
            val pk = "$lang|$prev"; val m = bi.getOrPut(pk) { HashMap() }; val bn = (m[word] ?: 0) + 1; m[word] = bn
            db.insertWithOnConflict("bi", null, ContentValues().apply { put("k", "$pk|$word"); put("prev", pk); put("word", word); put("n", bn) }, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    @Synchronized fun count(lang: String, w: String) = uni["$lang|$w"] ?: 0
    fun bonus(lang: String, w: String): Double { val n = count(lang, w); return if (n == 0) 0.0 else 2.0 + ln(n + 1.0) * 1.2 }

    @Synchronized fun topPrefix(lang: String, p: String, n: Int): List<String> {
        val pre = "$lang|"
        return uni.entries.filter { it.key.startsWith(pre) && it.key.substring(pre.length).startsWith(p) }
            .sortedByDescending { it.value }.take(n).map { it.key.substring(pre.length) }
    }

    @Synchronized fun next(lang: String, prev: String): List<Pair<String, Int>> =
        bi["$lang|$prev"]?.entries?.sortedByDescending { it.value }?.take(6)?.map { it.key to it.value } ?: emptyList()

    @Synchronized fun clear() {
        uni.clear(); bi.clear()
        writableDatabase.execSQL("DELETE FROM uni"); writableDatabase.execSQL("DELETE FROM bi")
    }
}
