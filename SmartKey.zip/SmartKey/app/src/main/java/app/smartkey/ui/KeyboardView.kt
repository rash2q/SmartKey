package app.smartkey.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import app.smartkey.*
import kotlin.math.abs
import kotlin.math.hypot

@SuppressLint("ViewConstructor")
class KeyboardView(ctx: Context) : View(ctx) {
    interface Listener {
        fun onChar(t: String)
        fun onSpecial(k: Kind)
        fun onSwipe(path: List<PointF>)
        fun onCursor(steps: Int)
    }

    private class KR(val key: Key, val cell: RectF, val draw: RectF)
    private inner class P(val id: Int, var kr: KR, val dx: Float, val dy: Float) {
        val path = ArrayList<PointF>(); val visited = HashSet<KR>()
        var swiping = false; var longShown = false; var sel = 0; var cursor = false; var lastX = dx; var done = false
        var items: List<String> = emptyList()
        val longRun = Runnable { if (!swiping && !cursor) { items = listOf(baseText(kr.key)) + kr.key.popup; longShown = true; sel = 0; tick(); invalidate() } }
        val delRun: Runnable = object : Runnable { override fun run() { listener?.onSpecial(Kind.DELETE); tick(); handler.postDelayed(this, 55) } }
    }

    var listener: Listener? = null
    var theme: KbTheme = Themes.get(ctx); set(v) { field = v; invalidate() }
    var shiftState = 0; set(v) { field = v; invalidate() }
    var enterLabel = "↵"; set(v) { field = v; invalidate() }
    var enterAccent = false; set(v) { field = v; invalidate() }
    var spaceLabel = "ع"; set(v) { field = v; invalidate() }
    var bottomPad = 12f
    var rowHeightDp = 54f
    private var swipeEnabled = true; private var preview = true; private var hapticLevel = 2; private var sound = false

    private var rows: List<List<Key>> = emptyList()
    private val krs = ArrayList<KR>()
    private val pointers = SparseArray<P>()
    private val handler = Handler(Looper.getMainLooper())
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trail = Path()
    private var keyFace: Typeface = Typeface.DEFAULT
    private val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val d = ctx.dp(1f)
    var keyWidth = 0f; private set

    fun applyPrefs() {
        val p = prefsOf(context)
        swipeEnabled = p.getBoolean("swipe", true); preview = p.getBoolean("popup_preview", true)
        hapticLevel = (p.getString("haptic", "2") ?: "2").toInt(); sound = p.getBoolean("sound", false)
        rowHeightDp = p.getInt("key_height", 54).toFloat(); bottomPad = p.getInt("bottom_padding", 12).toFloat()
        theme = Themes.get(context)
        val f = p.getString("key_font", "system") ?: "system"
        keyFace = try { if (f == "system") Typeface.DEFAULT else Typeface.createFromAsset(context.assets, "fonts/$f") } catch (_: Exception) { Typeface.DEFAULT }
        requestLayout()
    }

    fun setLayout(r: List<List<Key>>) { rows = r; pointers.clear(); requestLayout(); invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val hh = (rows.size * rowHeightDp * d + 6 * d + bottomPad * d).toInt()
        setMeasuredDimension(MeasureSpec.getSize(w), hh)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutKeys() }
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) { layoutKeys() }

    private fun layoutKeys() {
        krs.clear(); if (width == 0 || rows.isEmpty()) return
        val rh = rowHeightDp * d; val hg = 5f * d; val vg = 10f * d; var y = 6 * d
        var widths = 0f; var cnt = 0
        for (row in rows) {
            val tw = row.sumOf { it.weight.toDouble() }.toFloat(); val unit = (width - hg) / tw; var x = hg / 2
            for (k in row) {
                val cell = RectF(x, y, x + unit * k.weight, y + rh)
                val dr = RectF(cell.left + hg / 2, cell.top + vg / 2, cell.right - hg / 2, cell.bottom - vg / 2)
                krs.add(KR(k, cell, dr)); x += unit * k.weight
                if (k.kind == Kind.CHAR) { widths += unit; cnt++ }
            }
            y += rh
        }
        keyWidth = if (cnt > 0) widths / cnt else 40f * d
    }

    fun centers(): Map<String, PointF> {
        val m = HashMap<String, PointF>()
        for (k in krs) if (k.key.kind == Kind.CHAR && k.key.label.length == 1 && k.key.label[0].isLetter())
            m[k.key.label] = PointF(k.draw.centerX(), k.draw.centerY())
        return m
    }

    private fun hit(x: Float, y: Float): KR? {
        if (krs.isEmpty()) return null
        var best: KR? = null; var bd = Float.MAX_VALUE
        for (k in krs) {
            if (k.key.kind == Kind.SPACER) continue
            if (y < k.cell.top - 1 || y > k.cell.bottom + 1) continue
            val dx = if (x < k.cell.left) k.cell.left - x else if (x > k.cell.right) x - k.cell.right else 0f
            if (dx < bd) { bd = dx; best = k }
        }
        return best ?: krs.filter { it.key.kind != Kind.SPACER }.minByOrNull { abs(it.cell.centerY() - y) + abs(it.cell.centerX() - x) }
    }

    private fun baseText(k: Key): String =
        if (k.kind == Kind.CHAR && shiftState > 0 && k.label.length == 1 && k.label[0].code < 128) k.label.uppercase() else k.label

    private fun tick() {
        when (hapticLevel) {
            1 -> performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
            2 -> vib(7, 70); 3 -> vib(14, 160)
        }
        if (sound) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.5f)
    }
    @Suppress("DEPRECATION")
    private fun vib(ms: Long, amp: Int) {
        try { if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, amp)) else vibrator.vibrate(ms) } catch (_: Exception) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i)) }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> { val i = e.actionIndex; up(e.getPointerId(i), e.getX(i), e.getY(i)) }
            MotionEvent.ACTION_CANCEL -> { for (i in 0 until pointers.size()) stopCallbacks(pointers.valueAt(i)); pointers.clear(); trail.reset(); invalidate() }
        }
        return true
    }

    private fun stopCallbacks(p: P) { handler.removeCallbacks(p.longRun); handler.removeCallbacks(p.delRun) }

    private fun down(id: Int, x: Float, y: Float) {
        val kr = hit(x, y) ?: return
        val multi = pointers.size() > 0
        val p = P(id, kr, x, y); pointers.put(id, p); p.path.add(PointF(x, y)); p.visited.add(kr)
        tick()
        when {
            kr.key.kind == Kind.DELETE -> { listener?.onSpecial(Kind.DELETE); handler.postDelayed(p.delRun, 380) }
            multi && kr.key.kind == Kind.CHAR -> { listener?.onChar(baseText(kr.key)); p.done = true }
            kr.key.popup.isNotEmpty() -> handler.postDelayed(p.longRun, 330)
        }
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = pointers.get(id) ?: return
        if (p.done || p.kr.key.kind == Kind.DELETE) return
        p.path.add(PointF(x, y))
        if (p.longShown) { p.sel = popupIndex(p, x); invalidate(); return }
        if (p.kr.key.kind == Kind.SPACE) {
            if (p.cursor || abs(x - p.dx) > 16 * d) {
                p.cursor = true; val step = 11 * d; val n = ((x - p.lastX) / step).toInt()
                if (n != 0) { listener?.onCursor(n); p.lastX += n * step; tick() }
            }
            return
        }
        val k = hit(x, y)
        if (k != null) p.visited.add(k)
        if (swipeEnabled && !p.swiping && p.kr.key.kind == Kind.CHAR && p.kr.key.label.length == 1 && p.kr.key.label[0].isLetter()) {
            val dist = hypot(x - p.dx, y - p.dy)
            if (p.visited.size >= 3 || dist > keyWidth * 1.8f) { p.swiping = true; stopCallbacks(p) }
        }
        if (p.swiping) { trail.reset(); trail.moveTo(p.path[0].x, p.path[0].y); for (pt in p.path) trail.lineTo(pt.x, pt.y) }
        else if (k != null && k !== p.kr) { stopCallbacks(p); p.kr = k; if (k.key.popup.isNotEmpty()) handler.postDelayed(p.longRun, 330) }
        invalidate()
    }

    private fun up(id: Int, x: Float, y: Float) {
        val p = pointers.get(id) ?: return; pointers.remove(id); stopCallbacks(p)
        when {
            p.done || p.cursor || p.kr.key.kind == Kind.DELETE -> {}
            p.swiping -> { listener?.onSwipe(p.path) }
            p.longShown -> { if (p.sel in p.items.indices) listener?.onChar(p.items[p.sel]) }
            else -> fire(p.kr.key)
        }
        trail.reset(); invalidate()
    }

    private fun fire(k: Key) {
        when (k.kind) {
            Kind.CHAR -> listener?.onChar(baseText(k))
            Kind.SPACER -> {}
            else -> listener?.onSpecial(k.kind)
        }
    }

    private fun popupRect(p: P): RectF {
        val n = p.items.size; val w = keyWidth.coerceAtLeast(36 * d) * 1.05f; val total = w * n
        val l = (p.kr.draw.centerX() - total / 2).coerceIn(0f, (width - total).coerceAtLeast(0f))
        val t = (p.kr.draw.top - p.kr.draw.height() - 6 * d).coerceAtLeast(0f)
        return RectF(l, t, l + total, t + p.kr.draw.height() * 1.05f)
    }
    private fun popupIndex(p: P, x: Float): Int { val r = popupRect(p); return ((x - r.left) / (r.width() / p.items.size)).toInt().coerceIn(0, p.items.size - 1) }

    private fun shown(s: String): String = if (s.isNotEmpty() && Character.getType(s[0]) == Character.NON_SPACING_MARK.toInt()) "\u25CC$s" else s

    override fun onDraw(c: Canvas) {
        val t = theme; val rad = 6f * d
        val pressedSet = HashSet<KR>(); for (i in 0 until pointers.size()) { val p = pointers.valueAt(i); if (!p.swiping) pressedSet.add(p.kr) }
        paint.typeface = keyFace
        for (kr in krs) {
            val k = kr.key; if (k.kind == Kind.SPACER) continue
            val pressed = kr in pressedSet; val special = k.kind != Kind.CHAR && k.kind != Kind.SPACE
            val accent = k.kind == Kind.ENTER && enterAccent
            paint.style = Paint.Style.FILL
            if (!t.flat) { paint.color = t.shadow; c.drawRoundRect(kr.draw.left, kr.draw.top + 1.3f * d, kr.draw.right, kr.draw.bottom + 1.3f * d, rad, rad, paint) }
            paint.color = when { accent -> t.accent; special -> if (pressed) t.specialDown else t.special; else -> if (pressed) t.keyDown else t.key }
            c.drawRoundRect(kr.draw, rad, rad, paint)
            paint.color = if (accent) Color.WHITE else t.text
            paint.textAlign = Paint.Align.CENTER
            val label = when (k.kind) {
                Kind.SHIFT -> when (shiftState) { 0 -> "⇧"; 1 -> "⬆"; else -> "⇪" }
                Kind.ENTER -> enterLabel
                Kind.SPACE -> ""
                else -> shown(baseText(k))
            }
            paint.textSize = (if (special) 17f else 23f) * d * (if (k.kind == Kind.CHAR && rows.size > 4 && k.label.length == 1 && k.label[0].isDigit()) 0.9f else 1f)
            if (k.kind == Kind.ENTER && label.length > 1) paint.textSize = 16f * d
            val fm = paint.fontMetrics
            c.drawText(label, kr.draw.centerX(), kr.draw.centerY() - (fm.ascent + fm.descent) / 2, paint)
            if (k.kind == Kind.SPACE) {
                paint.color = t.subText; paint.textSize = 13f * d; paint.textAlign = Paint.Align.RIGHT
                c.drawText(spaceLabel, kr.draw.right - 10 * d, kr.draw.bottom - 8 * d, paint)
            }
        }
        if (!trail.isEmpty) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 5 * d; paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
            paint.color = (t.accent and 0x00FFFFFF) or 0xAA000000.toInt(); c.drawPath(trail, paint); paint.style = Paint.Style.FILL
        }
        paint.typeface = keyFace
        for (i in 0 until pointers.size()) {
            val p = pointers.valueAt(i)
            if (p.longShown) drawPopup(c, p)
            else if (preview && !p.swiping && !p.cursor && p.kr.key.kind == Kind.CHAR) drawBubble(c, p.kr)
        }
    }

    private fun drawBubble(c: Canvas, kr: KR) {
        val w = kr.draw.width() * 1.4f; val h = kr.draw.height() * 1.25f
        val l = (kr.draw.centerX() - w / 2).coerceIn(0f, width - w); val tp = (kr.draw.top - h + 8 * d).coerceAtLeast(0f)
        val r = RectF(l, tp, l + w, tp + h)
        paint.color = theme.shadow; c.drawRoundRect(r.left, r.top + 2 * d, r.right, r.bottom + 2 * d, 10 * d, 10 * d, paint)
        paint.color = theme.popupBg; c.drawRoundRect(r, 10 * d, 10 * d, paint)
        paint.color = theme.text; paint.textSize = 32 * d; paint.textAlign = Paint.Align.CENTER
        val fm = paint.fontMetrics; c.drawText(shown(baseText(kr.key)), r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, paint)
    }

    private fun drawPopup(c: Canvas, p: P) {
        val r = popupRect(p); val iw = r.width() / p.items.size
        paint.color = theme.shadow; c.drawRoundRect(r.left, r.top + 2 * d, r.right, r.bottom + 2 * d, 10 * d, 10 * d, paint)
        paint.color = theme.popupBg; c.drawRoundRect(r, 10 * d, 10 * d, paint)
        paint.textAlign = Paint.Align.CENTER; paint.textSize = 24 * d
        for ((i, s) in p.items.withIndex()) {
            val cell = RectF(r.left + i * iw + 3 * d, r.top + 3 * d, r.left + (i + 1) * iw - 3 * d, r.bottom - 3 * d)
            if (i == p.sel) { paint.color = theme.accent; c.drawRoundRect(cell, 8 * d, 8 * d, paint) }
            paint.color = if (i == p.sel) Color.WHITE else theme.text
            val fm = paint.fontMetrics; c.drawText(shown(s), cell.centerX(), cell.centerY() - (fm.ascent + fm.descent) / 2, paint)
        }
    }
}
