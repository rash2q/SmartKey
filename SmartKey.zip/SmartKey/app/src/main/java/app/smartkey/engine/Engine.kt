package app.smartkey.engine

import android.content.Context
import android.graphics.PointF
import app.smartkey.Layouts
import kotlin.concurrent.thread
import kotlin.math.hypot
import kotlin.math.ln

class Engine(private val ctx: Context) {
    val user = UserDb(ctx)
    private val dicts = HashMap<String, Dict>()
    private val bigrams = HashMap<String, Bigrams>()
    private val nbCache = HashMap<String, Map<Char, String>>()
    @Volatile var ready = false

    init {
        thread(name = "dict-loader") {
            for (l in listOf("ar", "en")) {
                val d = Dict(l); d.load(ctx)
                val b = Bigrams(l); b.load(ctx)
                synchronized(this) { dicts[l] = d; bigrams[l] = b }
            }
            ready = true
        }
    }

    @Synchronized private fun dict(l: String) = dicts[l]
    @Synchronized private fun big(l: String) = bigrams[l]
    private fun nb(l: String) = nbCache.getOrPut(l) { Layouts.neighbors(l) }

    private val confusable = mapOf(
        'ا' to "أإآٱ", 'أ' to "اإآ", 'إ' to "اأآ", 'آ' to "اأإ", 'ي' to "ىئ", 'ى' to "يئ", 'ئ' to "يى",
        'ه' to "ة", 'ة' to "ه", 'و' to "ؤ", 'ؤ' to "و"
    )

    class Result(val list: List<String>, val typedKnown: Boolean)

    private fun matchCase(typed: String, w: String): String = when {
        typed.length > 1 && typed.all { it.isUpperCase() } -> w.uppercase()
        typed.isNotEmpty() && typed[0].isUpperCase() -> w.replaceFirstChar { it.uppercase() }
        else -> w
    }

    private fun nextBoost(lang: String, prev: String?): Map<String, Double> {
        if (prev.isNullOrEmpty()) return emptyMap()
        val m = HashMap<String, Double>()
        big(lang)?.map?.get(prev)?.forEachIndexed { r, w -> m[w] = 4.0 - 0.6 * r.coerceAtMost(5) }
        for ((w, n) in user.next(lang, prev)) m[w] = (m[w] ?: 0.0) + 3.0 + ln(n + 1.0) * 1.5
        return m
    }

    private fun edits(lang: String, w: String, d: Dict, maxEdit: Int): Map<String, Double> {
        val alpha = if (lang == "ar") "ابتثجحخدذرزسشصضطظعغفقكلمنهوىيءةأإآؤئ" else "abcdefghijklmnopqrstuvwxyz'"
        val near = nb(lang)
        val found = HashMap<String, Double>()
        fun gen(s: String, base: Double, sink: (String, Double) -> Unit) {
            for (i in s.indices) sink(s.removeRange(i, i + 1), base + 3.0)
            for (i in 0 until s.length - 1) sink(s.substring(0, i) + s[i + 1] + s[i] + s.substring(i + 2), base + 1.8)
            for (i in s.indices) for (c in alpha) if (c != s[i]) {
                val pen = when {
                    confusable[s[i]]?.contains(c) == true -> 0.5
                    near[s[i]]?.contains(c) == true -> 1.4
                    else -> 3.2
                }
                sink(s.substring(0, i) + c + s.substring(i + 1), base + pen)
            }
            for (i in 0..s.length) for (c in alpha) sink(s.substring(0, i) + c + s.substring(i), base + 3.0)
        }
        val level1 = HashMap<String, Double>()
        gen(w, 0.0) { c, p -> if (p < (level1[c] ?: 99.0)) level1[c] = p }
        for ((c, p) in level1) if (d.indexOf(c) >= 0) found[c] = p
        if (maxEdit >= 2 && found.size < 2) {
            var n = 0
            for ((c1, p1) in level1) {
                if (p1 > 3.3 || ++n > 400) continue
                gen(c1, p1) { c, p -> if (p <= 6.0 && c != w && d.indexOf(c) >= 0 && p < (found[c] ?: 99.0)) found[c] = p }
            }
        }
        found.remove(w)
        return found
    }

    fun suggest(lang: String, prev: String?, typedRaw: String): Result {
        val d = dict(lang) ?: return Result(emptyList(), true)
        val typed = Norm.clean(lang, typedRaw)
        if (typed.isEmpty()) return Result(emptyList(), true)
        val boost = nextBoost(lang, Norm.clean(lang, prev ?: ""))
        val cands = HashMap<String, Double>()
        fun add(w: String, s: Double) { val o = cands[w]; if (o == null || s > o) cands[w] = s }
        val exact = d.indexOf(typed) >= 0
        val userKnows = user.count(lang, typed) > 0
        for (i in d.prefix(typed, 8)) {
            val w = d.words[i]
            add(w, ln(d.freq[i] + 1.0) - 0.35 * (w.length - typed.length) + (boost[w] ?: 0.0) + user.bonus(lang, w) + if (w == typed) 1.0 else 0.0)
        }
        if (typed.length >= 2 && !(exact && typed.length <= 2)) {
            val maxEdit = if (typed.length >= 4 && !exact) 2 else 1
            for ((w, pen) in edits(lang, typed, d, maxEdit)) {
                val i = d.indexOf(w)
                add(w, ln(d.freq[i] + 1.0) - pen - (if (exact) 2.5 else 0.0) + (boost[w] ?: 0.0) + user.bonus(lang, w))
            }
        }
        for (w in user.topPrefix(lang, typed, 3)) add(w, 8.0 + user.bonus(lang, w))
        val list = cands.entries.sortedByDescending { it.value }.map { matchCase(typedRaw, it.key) }.distinct().take(3)
        return Result(list, exact || userKnows)
    }

    fun nextWords(lang: String, prevRaw: String?): List<String> {
        val d = dict(lang)
        val prev = Norm.clean(lang, prevRaw ?: "")
        val out = LinkedHashSet<String>()
        if (prev.isNotEmpty()) {
            val boost = nextBoost(lang, prev)
            boost.entries.sortedByDescending { it.value }.forEach { out.add(it.key) }
        }
        if (out.size < 3 && d != null) for (i in d.top) { out.add(d.words[i]); if (out.size >= 3) break }
        return out.take(3)
    }

    /** Fast, synchronous: returns the corrected word or the typed word unchanged. */
    fun quickCorrect(lang: String, prev: String?, typedRaw: String): String {
        val d = dict(lang) ?: return typedRaw
        val typed = Norm.clean(lang, typedRaw)
        if (typed.length < 2 || typed.any { it.isDigit() || it == '@' || it == '.' || it == '/' }) return typedRaw
        if (d.indexOf(typed) >= 0 || user.count(lang, typed) > 0) return typedRaw
        val boost = nextBoost(lang, Norm.clean(lang, prev ?: ""))
        var best: String? = null; var bs = -99.0
        for ((w, pen) in edits(lang, typed, d, 1)) {
            val s = ln(d.freq[d.indexOf(w)] + 1.0) - pen * 1.3 + (boost[w] ?: 0.0) + user.bonus(lang, w)
            if (s > bs) { bs = s; best = w }
        }
        return if (best != null) matchCase(typedRaw, best) else typedRaw
    }

    // ---------- swipe typing (SHARK2-style template matching) ----------
    private fun resample(p: List<PointF>, n: Int): List<PointF> {
        var len = 0f
        for (i in 1 until p.size) len += hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y)
        if (len == 0f) return List(n) { p[0] }
        val step = len / (n - 1); val out = ArrayList<PointF>(n); out.add(PointF(p[0].x, p[0].y))
        var acc = 0f; var prev = p[0]; var i = 1
        while (i < p.size && out.size < n) {
            val cur = p[i]; val seg = hypot(cur.x - prev.x, cur.y - prev.y)
            if (seg > 0f && acc + seg >= step) {
                val t = (step - acc) / seg
                val q = PointF(prev.x + t * (cur.x - prev.x), prev.y + t * (cur.y - prev.y))
                out.add(q); prev = q; acc = 0f
            } else { acc += seg; prev = cur; i++ }
        }
        while (out.size < n) out.add(PointF(p.last().x, p.last().y))
        return out
    }

    fun swipe(lang: String, path: List<PointF>, centers: Map<String, PointF>, kw: Float): List<String> {
        val d = dict(lang) ?: return emptyList()
        if (path.size < 4 || centers.isEmpty()) return emptyList()
        fun near(p: PointF) = centers.filter { hypot(it.value.x - p.x, it.value.y - p.y) < kw * 1.3f }.keys
        val firsts = near(path.first()); val lasts = near(path.last())
        if (firsts.isEmpty() || lasts.isEmpty()) return emptyList()
        val N = 48; val up = resample(path, N)
        val scored = ArrayList<Pair<String, Double>>(); var seen = 0
        for (i in d.byFreq()) {
            val w = d.words[i]; if (w.length < 2) continue
            if (Norm.swipeBase(w.first()).toString() !in firsts || Norm.swipeBase(w.last()).toString() !in lasts) continue
            if (++seen > 4000) break
            val pts = ArrayList<PointF>(); var ok = true; var pc = ' '
            for (c0 in w) {
                val c = Norm.swipeBase(c0); if (c == pc) continue
                val ctr = centers[c.toString()]; if (ctr == null) { ok = false; break }
                pts.add(ctr); pc = c
            }
            if (!ok) continue
            if (pts.size < 2) pts.add(pts[0])
            val t = resample(pts, N); var s = 0.0
            for (k in 0 until N) s += hypot(up[k].x - t[k].x, up[k].y - t[k].y)
            scored.add(w to (s / N / kw) * 2.2 - ln(d.freq[i] + 1.0) * 0.12 - user.bonus(lang, w) * 0.1)
        }
        return scored.sortedBy { it.second }.take(5).map { it.first }
    }
}
