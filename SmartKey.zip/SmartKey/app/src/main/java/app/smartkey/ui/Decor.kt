package app.smartkey.ui

/** Text decoration: kashida (tatweel), tashkeel, fancy Latin alphabets, wrappers. */
object Decor {
    private const val TAT = "ـ"
    private val noJoinAfter = "ادذرزوؤةءأإآى"
    private fun isAr(c: Char) = c in '\u0621'..'\u064A'

    fun tatweel(s: String, n: Int): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            if (isAr(s[i]) && s[i] !in noJoinAfter && i + 1 < s.length && isAr(s[i + 1])) repeat(n) { sb.append(TAT) }
        }
        return sb.toString()
    }
    fun strip(s: String) = s.replace(Regex("[\u064B-\u065F\u0670\u0640]"), "")
    fun mark(s: String, m: String): String { val sb = StringBuilder(); for (c in strip(s)) { sb.append(c); if (isAr(c)) sb.append(m) }; return sb.toString() }

    private fun mathAlpha(s: String, upper: Int, lower: Int, digit: Int = -1, ex: Map<Char, Int> = emptyMap()): String {
        val sb = StringBuilder()
        for (c in s) when {
            ex.containsKey(c) -> sb.appendCodePoint(ex[c]!!)
            c in 'A'..'Z' -> sb.appendCodePoint(upper + (c - 'A'))
            c in 'a'..'z' -> sb.appendCodePoint(lower + (c - 'a'))
            c in '0'..'9' && digit >= 0 -> sb.appendCodePoint(digit + (c - '0'))
            else -> sb.append(c)
        }
        return sb.toString()
    }
    private fun shift(s: String, up: Int, lo: Int): String {
        val sb = StringBuilder(); for (c in s) sb.appendCodePoint(when (c) { in 'A'..'Z' -> up + (c - 'A'); in 'a'..'z' -> lo + (c - 'a'); else -> c.code }); return sb.toString()
    }
    private val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
    private fun small(s: String) = s.map { if (it in 'a'..'z') smallCaps[it - 'a'] else it }.joinToString("")
    private fun combine(s: String, m: Char) = s.map { if (it.isWhitespace()) "$it" else "$it$m" }.joinToString("")

    class Style(val name: String, val f: (String) -> String)

    val styles: List<Style> = listOf(
        Style("تطويل خفيف") { tatweel(it, 1) },
        Style("تطويل متوسط") { tatweel(it, 2) },
        Style("تطويل طويل") { tatweel(it, 4) },
        Style("إزالة التطويل والتشكيل") { strip(it) },
        Style("فتحة على كل حرف") { mark(it, "َ") },
        Style("شدّة وفتحة") { mark(it, "ّ") },
        Style("سكون") { mark(it, "ْ") },
        Style("﴿ نص ﴾") { "﴿ $it ﴾" },
        Style("꧁ نص ꧂") { "꧁ $it ꧂" },
        Style("✦ نص ✦") { "✦ $it ✦" },
        Style("『 نص 』") { "『$it』" },
        Style("♡ نص ♡") { "♡ $it ♡" },
        Style("• نص •") { "• $it •" },
        Style("حروف متباعدة") { it.toList().joinToString(" ") },
        Style("حروف منقّطة") { it.toList().joinToString("٭") },
        Style("مقلوب") { it.reversed() },
        Style("غامق Bold") { mathAlpha(it, 0x1D400, 0x1D41A, 0x1D7CE) },
        Style("مائل Italic") { mathAlpha(it, 0x1D434, 0x1D44E, -1, mapOf('h' to 0x210E)) },
        Style("خط يد Script") { mathAlpha(it, 0x1D49C, 0x1D4B6, -1, mapOf('B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110, 'L' to 0x2112, 'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134)) },
        Style("مفرغ Double") { mathAlpha(it, 0x1D538, 0x1D552, 0x1D7D8, mapOf('C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119, 'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124)) },
        Style("آلة كاتبة Mono") { mathAlpha(it, 0x1D670, 0x1D68A, 0x1D7F6) },
        Style("Sans غامق") { mathAlpha(it, 0x1D5D4, 0x1D5EE, 0x1D7EC) },
        Style("دوائر ⓐ") { s -> s.map { if (it in 'A'..'Z') String(Character.toChars(0x24B6 + (it - 'A'))) else if (it in 'a'..'z') String(Character.toChars(0x24D0 + (it - 'a'))) else "$it" }.joinToString("") },
        Style("عرض كامل Ａ") { s -> s.map { if (it in '!'..'~') String(Character.toChars(it.code + 0xFEE0)) else "$it" }.joinToString("") },
        Style("Small Caps") { small(it) },
        Style("خط وسطي") { combine(it, '\u0336') },
        Style("خط سفلي") { combine(it, '\u0332') }
    )
}
