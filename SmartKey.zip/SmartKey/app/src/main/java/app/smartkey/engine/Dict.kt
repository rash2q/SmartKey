package app.smartkey.engine

import android.content.Context
import java.util.PriorityQueue

object Norm {
    private val strip = Regex("[\u064B-\u065F\u0670\u0640]")
    fun ar(s: String) = strip.replace(s, "")
    fun clean(lang: String, s: String) = if (lang == "ar") ar(s) else s.lowercase()
    /** Map hamza/variant letters to the base key that exists on the layout (for swipe). */
    fun swipeBase(c: Char): Char = when (c) {
        'أ', 'إ', 'آ', 'ٱ' -> 'ا'; 'ؤ' -> 'و'; 'ئ' -> 'ي'; else -> c
    }
}

class Dict(val lang: String) {
    var words: Array<String> = emptyArray(); private set
    var freq: IntArray = IntArray(0); private set
    private val cache = HashMap<String, IntArray>()
    private var byFreqIdx: IntArray? = null
    var top: IntArray = IntArray(0); private set

    fun load(ctx: Context) {
        val list = ArrayList<Pair<String, Int>>(200_000)
        try {
            ctx.assets.open("dict_$lang.txt").bufferedReader().useLines { ls ->
                for (l in ls) {
                    val t = l.indexOf('\t'); if (t <= 0) continue
                    val w = Norm.clean(lang, l.substring(0, t))
                    val f = l.substring(t + 1).trim().toIntOrNull() ?: 1
                    if (w.isNotEmpty()) list.add(w to f)
                }
            }
        } catch (_: Exception) {}
        list.sortBy { it.first }
        val ws = ArrayList<String>(list.size); val fs = ArrayList<Int>(list.size)
        for ((w, f) in list) {
            if (ws.isNotEmpty() && ws.last() == w) { if (f > fs.last()) fs[fs.size - 1] = f }
            else { ws.add(w); fs.add(f) }
        }
        words = ws.toTypedArray(); freq = fs.toIntArray()
        top = byFreq().take(60).toIntArray()
    }

    fun byFreq(): IntArray {
        byFreqIdx?.let { return it }
        val r = words.indices.sortedByDescending { freq[it] }.toIntArray()
        byFreqIdx = r; return r
    }

    private fun lowerBound(p: String): Int {
        var lo = 0; var hi = words.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (words[m] < p) lo = m + 1 else hi = m }
        return lo
    }

    fun indexOf(w: String): Int { val i = lowerBound(w); return if (i < words.size && words[i] == w) i else -1 }

    fun prefix(p: String, n: Int): IntArray {
        cache[p]?.let { if (it.size >= n) return it.copyOf(n.coerceAtMost(it.size)) }
        val q = PriorityQueue<Int>(compareBy { freq[it] })
        var i = lowerBound(p); var scanned = 0
        while (i < words.size && words[i].startsWith(p) && scanned < 60000) {
            if (q.size < n) q.add(i) else if (freq[i] > freq[q.peek()!!]) { q.poll(); q.add(i) }
            i++; scanned++
        }
        val out = q.sortedByDescending { freq[it] }.toIntArray()
        if (p.length <= 2) cache[p] = out
        return out
    }
}

class Bigrams(val lang: String) {
    val map = HashMap<String, List<String>>()
    fun load(ctx: Context) {
        try {
            ctx.assets.open("bigram_$lang.txt").bufferedReader().useLines { ls ->
                for (l in ls) {
                    val t = l.indexOf('\t'); if (t <= 0) continue
                    val pair = l.substring(0, t).split(' ')
                    if (pair.size != 2) continue
                    val k = Norm.clean(lang, pair[0])
                    map[k] = (map[k] ?: emptyList()) + pair[1]
                }
            }
        } catch (_: Exception) {}
    }
}
