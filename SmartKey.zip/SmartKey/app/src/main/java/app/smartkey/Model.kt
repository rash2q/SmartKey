package app.smartkey

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.preference.PreferenceManager

enum class Kind { CHAR, SHIFT, DELETE, SPACE, ENTER, SYMBOLS, SYMBOLS2, ABC, EMOJI, LANG, SPACER }

data class Key(
    val label: String,
    val kind: Kind = Kind.CHAR,
    val weight: Float = 1f,
    val popup: List<String> = emptyList()
)

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun prefsOf(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

data class KbTheme(
    val bg: Int, val key: Int, val keyDown: Int, val special: Int, val specialDown: Int,
    val text: Int, val subText: Int, val shadow: Int, val accent: Int, val popupBg: Int,
    val flat: Boolean = false
)

object Themes {
    private val iosLight = KbTheme(0xFFD2D5DB.toInt(), 0xFFFFFFFF.toInt(), 0xFFE4E6EA.toInt(), 0xFFADB3BD.toInt(), 0xFFFFFFFF.toInt(),
        0xFF000000.toInt(), 0xFF6E6E73.toInt(), 0xFF8A8C90.toInt(), 0xFF007AFF.toInt(), 0xFFFFFFFF.toInt())
    private val iosDark = KbTheme(0xFF2B2B2E.toInt(), 0xFF5C5C60.toInt(), 0xFF7A7A7F.toInt(), 0xFF3E3E42.toInt(), 0xFF5C5C60.toInt(),
        0xFFFFFFFF.toInt(), 0xFFB0B0B5.toInt(), 0xFF101011.toInt(), 0xFF0A84FF.toInt(), 0xFF5C5C60.toInt())
    private val samsung = KbTheme(0xFFEDEEF1.toInt(), 0xFFFAFAFB.toInt(), 0xFFDADCE2.toInt(), 0xFFDCDDE2.toInt(), 0xFFC5C8D0.toInt(),
        0xFF111111.toInt(), 0xFF707070.toInt(), 0x00000000, 0xFF3E91FF.toInt(), 0xFFFFFFFF.toInt(), flat = true)
    private val midnight = KbTheme(0xFF0F1226.toInt(), 0xFF1B2040.toInt(), 0xFF2D3566.toInt(), 0xFF2A3160.toInt(), 0xFF3B4580.toInt(),
        0xFFE6E9FF.toInt(), 0xFF98A0D8.toInt(), 0xFF05060F.toInt(), 0xFF7C8CFF.toInt(), 0xFF2A3160.toInt())
    private val rose = KbTheme(0xFFF7DDE4.toInt(), 0xFFFFFFFF.toInt(), 0xFFFBE6EC.toInt(), 0xFFEFB7C6.toInt(), 0xFFFFFFFF.toInt(),
        0xFF4A1F2C.toInt(), 0xFF9A6474.toInt(), 0xFFB98A96.toInt(), 0xFFE5446D.toInt(), 0xFFFFFFFF.toInt())
    private val emerald = KbTheme(0xFFD6EBDD.toInt(), 0xFFFFFFFF.toInt(), 0xFFE6F3EA.toInt(), 0xFFA5CDB2.toInt(), 0xFFFFFFFF.toInt(),
        0xFF0F3320.toInt(), 0xFF4F7A60.toInt(), 0xFF7FA38D.toInt(), 0xFF1B9E5A.toInt(), 0xFFFFFFFF.toInt())
    private val amoled = KbTheme(0xFF000000.toInt(), 0xFF1A1A1A.toInt(), 0xFF333333.toInt(), 0xFF0D0D0D.toInt(), 0xFF262626.toInt(),
        0xFFFFFFFF.toInt(), 0xFF9A9A9A.toInt(), 0xFF000000.toInt(), 0xFF00E5A8.toInt(), 0xFF262626.toInt())

    fun get(ctx: Context): KbTheme = when (prefsOf(ctx).getString("theme", "auto")) {
        "ios_light" -> iosLight; "ios_dark" -> iosDark; "samsung" -> samsung
        "midnight" -> midnight; "rose" -> rose; "emerald" -> emerald; "amoled" -> amoled
        else -> {
            val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (night) iosDark else iosLight
        }
    }
}

object Layouts {
    val tashkeel = listOf("َ", "ُ", "ِ", "ً", "ٌ", "ٍ", "ْ", "ّ", "ـ", "ٰ")
    private val arPop = mapOf(
        'ا' to listOf("أ", "إ", "آ", "ء", "ٱ"), 'ي' to listOf("ئ", "ى"), 'و' to listOf("ؤ"),
        'ه' to listOf("ة"), 'ة' to listOf("ه"), 'ج' to listOf("چ"), 'ب' to listOf("پ"),
        'ف' to listOf("ڤ"), 'ك' to listOf("گ", "ک"), 'ز' to listOf("ژ"), 'ء' to listOf("ئ", "ؤ"),
        'ل' to listOf("لا", "لأ", "لإ", "لآ"), 'ى' to listOf("ي")
    )
    private val enPop = mapOf(
        'a' to listOf("à", "á", "â", "ä", "ã", "å", "æ"), 'e' to listOf("è", "é", "ê", "ë", "ē"),
        'i' to listOf("ì", "í", "î", "ï"), 'o' to listOf("ò", "ó", "ô", "ö", "õ", "ø"),
        'u' to listOf("ù", "ú", "û", "ü"), 'c' to listOf("ç", "ć"), 'n' to listOf("ñ"),
        's' to listOf("ß", "ś"), 'y' to listOf("ÿ", "ý")
    )
    private fun chars(s: String, pop: Map<Char, List<String>>) = s.map { Key(it.toString(), popup = pop[it] ?: emptyList()) }

    private fun digits(hindi: Boolean): List<Key> {
        val en = "1234567890"; val ar = "١٢٣٤٥٦٧٨٩٠"
        return (if (hindi) ar else en).map { Key(it.toString()) }
    }

    fun bottom(lang: String, hindi: Boolean) = listOf(
        Key(if (hindi && lang == "ar") "١٢٣" else "123", Kind.SYMBOLS, 1.4f),
        Key("🌐", Kind.LANG, 1.1f),
        Key("😀", Kind.EMOJI, 1.1f),
        Key(" ", Kind.SPACE, 4.4f),
        if (lang == "ar") Key("ّ", popup = tashkeel + listOf("،", "؟", "؛", "!", "."))
        else Key(".", popup = listOf(",", "?", "!", "'", ":", ";", "-")),
        Key("↵", Kind.ENTER, 1.8f)
    )

    fun letters(lang: String, numRow: Boolean, hindi: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        if (numRow) rows.add(digits(hindi && lang == "ar"))
        if (lang == "ar") {
            rows.add(chars("ضصثقفغعهخحج", arPop))
            rows.add(chars("شسيبلاتنمكة", arPop))
            rows.add(chars("ءظطذدزروى", arPop) + Key("", Kind.SPACER, 0.35f) + Key("⌫", Kind.DELETE, 1.5f))
        } else {
            rows.add(chars("qwertyuiop", enPop))
            rows.add(listOf(Key("", Kind.SPACER, 0.5f)) + chars("asdfghjkl", enPop) + Key("", Kind.SPACER, 0.5f))
            rows.add(listOf(Key("⇧", Kind.SHIFT, 1.5f)) + chars("zxcvbnm", enPop) + Key("⌫", Kind.DELETE, 1.5f))
        }
        rows.add(bottom(lang, hindi))
        return rows
    }

    fun symbols(page: Int, lang: String, hindi: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        rows.add(digits(hindi && lang == "ar"))
        if (page == 0) {
            rows.add("-/:;()$&@\"".map { Key(it.toString()) })
            rows.add(listOf(Key("#+=", Kind.SYMBOLS2, 1.5f)) + listOf(".", "،", "؟", "?", "!", "'").map { Key(it) } + Key("⌫", Kind.DELETE, 1.5f))
        } else {
            rows.add("[]{}#%^*+=".map { Key(it.toString()) })
            rows.add("_\\|~<>€£¥•".map { Key(it.toString()) })
            rows.add(listOf(Key("123", Kind.SYMBOLS, 1.5f)) + listOf(".", ",", "?", "!", "'", "؛").map { Key(it) } + Key("⌫", Kind.DELETE, 1.5f))
        }
        val b = bottom(lang, hindi).toMutableList()
        b[0] = Key(if (lang == "ar") "ابج" else "ABC", Kind.ABC, 1.4f)
        rows.add(b)
        return rows
    }

    /** letter -> adjacent letters (used for typo weighting). */
    fun neighbors(lang: String): Map<Char, String> {
        val rows = letters(lang, false, false).dropLast(1).map { r -> r.filter { it.kind == Kind.CHAR && it.label.length == 1 }.map { it.label[0] } }
        val m = HashMap<Char, StringBuilder>()
        for ((ri, row) in rows.withIndex()) for ((ci, c) in row.withIndex()) {
            val sb = m.getOrPut(c) { StringBuilder() }
            if (ci > 0) sb.append(row[ci - 1]); if (ci < row.size - 1) sb.append(row[ci + 1])
            for (dr in intArrayOf(-1, 1)) { val r2 = rows.getOrNull(ri + dr) ?: continue
                for (dc in -1..1) r2.getOrNull(ci + dc)?.let { sb.append(it) } }
        }
        return m.mapValues { it.value.toString() }
    }
}
