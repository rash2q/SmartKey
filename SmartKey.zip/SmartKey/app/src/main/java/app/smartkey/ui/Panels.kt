package app.smartkey.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.smartkey.*
import app.smartkey.data.ClipboardDb

private fun roundBg(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

// ---------------------------------------------------------------- Suggestion / toolbar strip
class SuggestionBar(ctx: Context, private val onPick: (String, Boolean) -> Unit, private val onTool: (String) -> Unit) : LinearLayout(ctx) {
    private val arrow = TextView(ctx)
    private val slots = List(3) { TextView(ctx) }
    private val slotRow = LinearLayout(ctx)
    private val toolRow = LinearLayout(ctx)
    private val toolScroll = HorizontalScrollView(ctx)
    private var literal: String? = null
    private var showingTools = false
    private var inPanel = false
    private var th = Themes.get(ctx)

    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        val d = ctx.dp(1f)
        arrow.text = "›"; arrow.textSize = 26f; arrow.gravity = Gravity.CENTER
        addView(arrow, LayoutParams((46 * d).toInt(), LayoutParams.MATCH_PARENT))
        arrow.setOnClickListener { if (inPanel) onTool("close") else { showingTools = !showingTools; refresh() } }
        slotRow.orientation = HORIZONTAL
        for ((i, s) in slots.withIndex()) {
            s.gravity = Gravity.CENTER; s.textSize = 18f; s.maxLines = 1; s.setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            slotRow.addView(s, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
            s.setOnClickListener { val t = s.text.toString(); if (t.isNotEmpty()) onPick(t.trim('“', '”'), t.startsWith("“")) }
        }
        toolRow.orientation = HORIZONTAL
        val tools = listOf("⚙️" to "settings", "📋" to "clipboard", "😀" to "emoji", "✨" to "decor", "⌨️" to "ime", "↔️" to "onehand", "🎨" to "theme", "☑️" to "selectall", "📄" to "copy", "✂️" to "cut", "📥" to "paste")
        for ((ic, id) in tools) toolRow.addView(TextView(ctx).apply {
            text = ic; textSize = 22f; gravity = Gravity.CENTER; setPadding((16 * d).toInt(), 0, (16 * d).toInt(), 0)
            setOnClickListener { onTool(id) }
        }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT))
        toolScroll.addView(toolRow); toolScroll.isHorizontalScrollBarEnabled = false
        addView(slotRow, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        addView(toolScroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        refresh()
    }

    fun applyTheme(t: KbTheme) {
        th = t; arrow.setTextColor(t.text)
        for (s in slots) s.setTextColor(t.text)
        for (i in 0 until toolRow.childCount) (toolRow.getChildAt(i) as TextView).setTextColor(t.text)
        setBackgroundColor(t.bg)
    }

    fun setPanelMode(on: Boolean) { inPanel = on; showingTools = false; arrow.text = if (on) "⌨" else "›"; refresh() }

    private fun refresh() {
        slotRow.visibility = if (showingTools || inPanel) GONE else VISIBLE
        toolScroll.visibility = if (showingTools || inPanel) VISIBLE else GONE
        if (!inPanel) arrow.text = if (showingTools) "‹" else "›"
    }

    /** center = best, left = typed literal (if unknown) or 2nd, right = 3rd */
    fun set(list: List<String>, typed: String?) {
        for (s in slots) { s.text = ""; s.setTypeface(null, Typeface.NORMAL) }
        if (list.isEmpty()) return
        if (typed != null && typed.isNotEmpty() && list[0] != typed) {
            slots[0].text = "“$typed”"; slots[1].text = list[0]; list.getOrNull(1)?.let { slots[2].text = it }
        } else {
            slots[1].text = list[0]; list.getOrNull(1)?.let { slots[0].text = it }; list.getOrNull(2)?.let { slots[2].text = it }
        }
        slots[1].setTypeface(null, Typeface.BOLD)
        if (showingTools) { showingTools = false; refresh() }
    }
    fun clear() = set(emptyList(), null)
}

// ---------------------------------------------------------------- Clipboard (Samsung style)
class ClipboardPanel(ctx: Context, private val db: ClipboardDb, private val onPaste: (String, String) -> Unit) : ScrollView(ctx) {
    private val box = LinearLayout(ctx)
    private var th = Themes.get(ctx)
    init { box.orientation = LinearLayout.VERTICAL; addView(box); val d = ctx.dp(1f); box.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (10 * d).toInt()) }

    fun show(t: KbTheme) { th = t; setBackgroundColor(t.bg); rebuild() }

    private fun header(txt: String, action: String? = null, onAction: (() -> Unit)? = null) {
        val d = context.dp(1f)
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (8 * d).toInt(), 0, (4 * d).toInt()) }
        row.addView(TextView(context).apply { text = txt; setTextColor(th.subText); textSize = 14f }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (action != null) row.addView(TextView(context).apply { text = action; setTextColor(th.accent); textSize = 14f; setOnClickListener { onAction?.invoke() } })
        box.addView(row)
    }

    private fun rebuild() {
        box.removeAllViews()
        val pinned = db.list(true); val recent = db.list(false)
        if (pinned.isEmpty() && recent.isEmpty()) {
            box.addView(TextView(context).apply { text = "لا يوجد شيء منسوخ بعد.\nانسخ نصاً وسيظهر هنا."; setTextColor(th.subText); gravity = Gravity.CENTER; setPadding(0, 60, 0, 60) })
            return
        }
        if (pinned.isNotEmpty()) { header("📌 المثبّتة"); grid(pinned) }
        if (recent.isNotEmpty()) { header("🕒 الأخيرة", "مسح الكل") { db.clearUnpinned(); rebuild() }; grid(recent) }
    }

    private fun grid(items: List<app.smartkey.data.ClipItem>) {
        val d = context.dp(1f)
        for (pair in items.chunked(2)) {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (it in pair) row.addView(card(it), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt()) })
            if (pair.size == 1) row.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            box.addView(row)
        }
    }

    private fun card(it: app.smartkey.data.ClipItem): View {
        val d = context.dp(1f)
        val c = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; background = roundBg(th.key, 10 * d); setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (6 * d).toInt()) }
        c.addView(TextView(context).apply {
            text = if (it.type == "IMAGE") "🖼  صورة" else it.content; setTextColor(if (it.type == "LINK") th.accent else th.text)
            maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END; textSize = 15f; minLines = 2
        })
        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        actions.addView(TextView(context).apply { text = if (it.pinned) "📍" else "📌"; textSize = 16f; setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt()); setOnClickListener { _ -> db.togglePin(it.id); rebuild() } })
        actions.addView(TextView(context).apply { text = "✕"; setTextColor(th.subText); textSize = 15f; setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt()); setOnClickListener { _ -> db.delete(it.id); rebuild() } })
        c.addView(actions)
        c.setOnClickListener { _ -> onPaste(it.content, it.type) }
        return c
    }
}

// ---------------------------------------------------------------- Emoji
class EmojiPanel(ctx: Context, private val onEmoji: (String) -> Unit, private val onBack: () -> Unit, private val onDelete: () -> Unit) : LinearLayout(ctx) {
    private class Group(val name: String, val icon: String, val items: List<String>)
    private val groups = ArrayList<Group>()
    private val rv = RecyclerView(ctx)
    private val tabs = LinearLayout(ctx)
    private var face: Typeface? = null
    private var th = Themes.get(ctx)
    private val recentKey = "recent_emoji"
    private val icons = mapOf("Smileys & Emotion" to "😀", "People & Body" to "👋", "Animals & Nature" to "🐻", "Food & Drink" to "🍔",
        "Travel & Places" to "🚗", "Activities" to "⚽", "Objects" to "💡", "Symbols" to "🔣", "Flags" to "🏁")

    init {
        orientation = VERTICAL
        loadData()
        val d = ctx.dp(1f)
        rv.layoutManager = GridLayoutManager(ctx, 8)
        addView(rv, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        tabs.orientation = HORIZONTAL
        addView(tabs, LayoutParams(LayoutParams.MATCH_PARENT, (44 * d).toInt()))
    }

    private fun loadData() {
        val p = prefsOf(context)
        val recent = (p.getString(recentKey, "") ?: "").split(' ').filter { it.isNotEmpty() }
        groups.add(Group("Recent", "🕒", recent))
        try {
            var name = ""; var cur = ArrayList<String>()
            context.assets.open("emoji.txt").bufferedReader().useLines { ls ->
                for (l in ls) {
                    if (l.startsWith("##")) { if (name.isNotEmpty()) groups.add(Group(name, icons[name] ?: "•", cur)); name = l.substring(2).trim(); cur = ArrayList() }
                    else if (l.isNotBlank()) cur.add(l.substringBefore('\t'))
                }
                if (name.isNotEmpty()) groups.add(Group(name, icons[name] ?: "•", cur))
            }
        } catch (_: Exception) {}
    }

    fun show(t: KbTheme) {
        th = t; setBackgroundColor(t.bg)
        val f = prefsOf(context).getString("emoji_font", "system") ?: "system"
        face = try { if (f == "system") null else Typeface.createFromAsset(context.assets, "fonts/$f") } catch (_: Exception) { null }
        val recent = (prefsOf(context).getString(recentKey, "") ?: "").split(' ').filter { it.isNotEmpty() }
        groups[0] = Group("Recent", "🕒", recent)
        tabs.removeAllViews()
        val d = context.dp(1f)
        tabs.addView(tabBtn("ابج") { onBack() }, LayoutParams(0, LayoutParams.MATCH_PARENT, 1.3f))
        for ((i, g) in groups.withIndex()) tabs.addView(tabBtn(g.icon) { select(i) }, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        tabs.addView(tabBtn("⌫") { onDelete() }, LayoutParams(0, LayoutParams.MATCH_PARENT, 1.3f))
        select(if (recent.isEmpty() && groups.size > 1) 1 else 0)
    }

    private fun tabBtn(txt: String, click: () -> Unit) = TextView(context).apply {
        text = txt; textSize = 19f; gravity = Gravity.CENTER; setTextColor(th.text); if (face != null) typeface = face; setOnClickListener { click() }
    }

    private fun select(i: Int) {
        val items = groups[i].items
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = items.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val tv = TextView(p.context).apply { textSize = 28f; gravity = Gravity.CENTER; layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (46 * p.context.dp(1f)).toInt()); setTextColor(th.text) }
                return object : RecyclerView.ViewHolder(tv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val tv = h.itemView as TextView; tv.text = items[pos]; if (face != null) tv.typeface = face
                tv.setOnClickListener { pick(items[pos]) }
            }
        }
        rv.scrollToPosition(0)
    }

    private fun pick(e: String) {
        onEmoji(e)
        val p = prefsOf(context)
        val r = ((p.getString(recentKey, "") ?: "").split(' ').filter { it.isNotEmpty() && it != e }).toMutableList(); r.add(0, e)
        p.edit().putString(recentKey, r.take(32).joinToString(" ")).apply()
    }
}

// ---------------------------------------------------------------- Decoration / kashida panel
class DecorPanel(ctx: Context, private val onApply: (String) -> Unit) : LinearLayout(ctx) {
    private val list = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val title = TextView(ctx)
    init {
        orientation = VERTICAL; scroll.addView(list); list.orientation = VERTICAL
        val d = ctx.dp(1f)
        title.textSize = 13f; title.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (4 * d).toInt())
        addView(title); addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }
    fun show(t: KbTheme, source: String) {
        setBackgroundColor(t.bg); list.removeAllViews(); val d = context.dp(1f)
        title.setTextColor(t.subText)
        val src = source.ifEmpty { "محمد" }
        title.text = if (source.isEmpty()) "اكتب كلمة أو حدّد نصاً ثم افتح الزخرفة (معاينة: $src)" else "اضغط على النمط لتطبيقه على: $src"
        for (st in Decor.styles) {
            val out = st.f(src)
            list.addView(TextView(context).apply {
                text = out; setTextColor(t.text); textSize = 20f; setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
                background = roundBg(t.key, 10 * d); setOnClickListener { onApply(out) }
            }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { setMargins((10 * d).toInt(), (3 * d).toInt(), (10 * d).toInt(), (3 * d).toInt()) })
            list.addView(TextView(context).apply { text = st.name; setTextColor(t.subText); textSize = 11f; setPadding((16 * d).toInt(), 0, 0, 0) })
        }
    }
}
